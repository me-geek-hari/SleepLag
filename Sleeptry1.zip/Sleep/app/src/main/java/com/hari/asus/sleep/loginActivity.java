package com.hari.asus.sleep;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class loginActivity extends AppCompatActivity {
    private EditText login_email;
    private EditText login_password;
    private Button login_login;
    private Button login_new;
    private ProgressBar progressBar;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        login_email = findViewById(R.id.editTextTextEmailAddress);
        login_password = findViewById(R.id.editTextTextPassword);
        login_login = findViewById(R.id.button);
        login_new = findViewById(R.id.button2);
        progressBar = findViewById(R.id.progressBar);

        mAuth = FirebaseAuth.getInstance();

        login_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String loginemail = login_email.getText().toString();
                String loginPass = login_password.getText().toString();

                if(!TextUtils.isEmpty(loginemail)&&!TextUtils.isEmpty(loginPass)){
                    progressBar.setVisibility(View.VISIBLE);
                    mAuth.signInWithEmailAndPassword(loginemail,loginPass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if(task.isSuccessful()){
                                sendtomain();
                            }else{
                                String errormessage = task.getException().getMessage();
                                Toast.makeText(loginActivity.this, "error : "+errormessage, Toast.LENGTH_SHORT).show();
                            }
                            progressBar.setVisibility(View.INVISIBLE);
                        }
                    });
                }else{
                    Toast.makeText(loginActivity.this, "All fields are necessary", Toast.LENGTH_SHORT).show();
                }

            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseUser currentuser = mAuth.getCurrentUser();

        if(currentuser!=null){sendtomain();}
    }

    private void sendtomain() {


            Intent mainintent  = new Intent(loginActivity.this,MainActivity.class);
            startActivity(mainintent);
            finish();

    }
}